var value="Copyright @ 2017 Roila Youth Club";
document.getElementById("fo").innerHTML=value;